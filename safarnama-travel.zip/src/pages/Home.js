
import React from 'react';

const Home = () => {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Safarnama</h1>
      <h2>Where every journey becomes a story.</h2>
      <p>Explore packages: Kerala, Goa, Kashmir, Ladakh, Andaman, Dubai, Singapore, Europe, USA, Australia, South Africa, Kenya</p>
      <button style={{ padding: '0.5rem 1rem', fontSize: '1rem' }}>Inquiry Form</button>
      <p style={{ marginTop: '2rem', color: 'gray' }}>Gallery & Blog: Coming Soon</p>
    </div>
  );
};

export default Home;
